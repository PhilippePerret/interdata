# Interdata::Film

Dossier contenant toutes les données sur les films, utilisables par les différentes applications.